# Changelog

All Notable changes to `discord` will be documented in this file

## 1.0.0 - 2017-08-14

- initial release
