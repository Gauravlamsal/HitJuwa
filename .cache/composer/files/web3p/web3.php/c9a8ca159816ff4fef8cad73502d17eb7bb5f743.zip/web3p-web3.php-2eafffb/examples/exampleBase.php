<?php

require('../vendor/autoload.php');

use Web3\Web3;

$web3 = new Web3('http://192.168.99.100:8545/');