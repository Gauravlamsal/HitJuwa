<?php

namespace Test;

use \PHPUnit\Framework\TestCase as BaseTestCase;

class TestCase extends BaseTestCase
{
    /**
     * setUp
     * 
     * @return void
     */
    public function setUp(): void {}

    /**
     * tearDown
     * 
     * @return void
     */
    public function tearDown(): void {}
}