# ethereum-util

[![PHP](https://github.com/web3p/ethereum-util/actions/workflows/php.yml/badge.svg)](https://github.com/web3p/ethereum-util/actions/workflows/php.yml)
[![codecov](https://codecov.io/gh/web3p/ethereum-util/branch/master/graph/badge.svg)](https://codecov.io/gh/web3p/ethereum-util)
[![Licensed under the MIT License](https://img.shields.io/badge/License-MIT-blue.svg)](https://github.com/web3p/ethereum-util/blob/master/LICENSE)

A collection of utility functions for Ethereum written in php.
