<?php

namespace Myoutdeskllc\LaravelAnalyticsV4\Exceptions;

class InvalidMetricException extends \InvalidArgumentException
{
}
