<?php

namespace Myoutdeskllc\LaravelAnalyticsV4\Exceptions;

class InvalidDimensionException extends \InvalidArgumentException
{
}
