# Changelog

All notable changes to `Laravel-Analytics-V4` will be documented in this file.

## 0.0.2 - Bug Fix - 2022-09-21

### 0.0.2

Contains bug fix for https://github.com/MyOutDeskLLC/Laravel-Analytics-V4/issues/4, in addition to implementing phpstan recommendations.

## 0.0.2 - development environment update  - 2022-09-16

Updates dev environment to use .env file.

## 0.0.1 Release - 2022-09-08

Initial Release
