Change log
==========

## [2.1.0] - 2017-12-22

### Added

- travis notifies irc channel #dspacelabs

### Updated

- [#18] Avoid reliance on own PSR-7 implementation
- [#29] Added Test Case for CurlDriver

## [2.0.2] - 2015-05-27

### Fixed

- [#16] incompatible with psr/http-message current version

## [2.0.1] - 2015-03-27

### Added

- Added Vagrant file to setup and configure nodes

### Fixed

- Small issue with the CurlDriver


## [2.0.0] - 2015-03-22

Initial release of 2.x

### Added

- Message
- Streamable
- Request
- Response
- Command

### Changed

- Complete Rewrite of Library

### Deprecated

- 1.x Releases

[unreleased]: https://github.com/nbobtc/bitcoind-php/compare/2.1.0...2.x
[2.1.0]: https://github.com/nbobtc/bitcoind-php/compare/2.0.2...2.1.0
[2.0.2]: https://github.com/nbobtc/bitcoind-php/compare/2.0.1...2.0.2
[2.0.1]: https://github.com/nbobtc/bitcoind-php/compare/2.0.0...2.0.1
[2.0.0]: https://github.com/nbobtc/bitcoind-php/compare/2d30e2f9ee617f44336581386cd0734613c7353d...2.0.0
[#16]: https://github.com/nbobtc/bitcoind-php/issues/16
[#18]: https://github.com/nbobtc/bitcoind-php/pull/18
[#29]: https://github.com/nbobtc/bitcoind-php/pull/29
