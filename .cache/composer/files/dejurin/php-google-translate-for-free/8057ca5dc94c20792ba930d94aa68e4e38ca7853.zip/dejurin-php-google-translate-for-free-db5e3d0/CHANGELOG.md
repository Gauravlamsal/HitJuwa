# GoogleTranslateForFree PHP Library Changelog
Author: Yuri Darwin
Author e-mail: gkhelloworld@gmail.com

## v1.0.0
This is the first release of Google Translate for Free library by Yuri Darwin